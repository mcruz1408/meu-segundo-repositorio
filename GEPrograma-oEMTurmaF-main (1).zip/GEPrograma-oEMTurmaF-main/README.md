# GEPrograma-oEMTurmaF
# PROJETO BARBEARIA ALURA
## tamanho
### tamanho
** tentativas de sintaxe

 ![](https://sdk.bitmoji.com/render/panel/6036f1b8-60b6-4c65-94bb-9047349273b2-6115c3ca-7452-436c-8f52-5e0810662fd4-v1.png?transparent=1&palette=1)
![](https://sdk.bitmoji.com/render/panel/18671f14-b792-4741-aa8d-4957dcd98a68-6115c3ca-7452-436c-8f52-5e0810662fd4-v1.png?transparent=1&palette=1)
![](![image](https://user-images.githubusercontent.com/104499941/176662961-0c7e4751-7687-4db1-b5b3-332a6c32e7a8.png)
(![image](https://user-images.githubusercontent.com/104499941/176663133-0b3b01a3-8dc4-43a9-bc98-48599fcfdff3.png)
(![image](https://user-images.githubusercontent.com/104499941/176663342-b93e73fb-eb4c-43e1-a67c-5a56b4460a83.png)
![image](https://user-images.githubusercontent.com/104499941/176663527-42b75063-702d-42fa-a673-24ed73f5ef1f.png)



 
